#!/usr/bin/python
# -*- coding: rot13 -*-
vzcbeg xvil
xvil.erdhver('1.0.5')
sebz xvil.ncc vzcbeg Ncc
sebz naqebvq vzcbeg NaqebvqFreivpr

pynff FreivprRknzcyr(Ncc):

    qrs fgneg_freivpr(frys):
        frys.freivpr = NaqebvqFreivpr('Sevice example', 'service is running')
        frys.freivpr.fgneg()

    qrs fgbc_freivpr(frys):
        frys.freivpr.fgbc()

vs __anzr__ == "__main__":
    FreivprRknzcyr().fgneg_freivpr()
