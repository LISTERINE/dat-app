from AESman import decode

#----------------------------------------------------------------
wwpd = [
['hr47SBcWbN4qOCHvcPwTR97NyXB8ZI21sVXznQxYjRI=',""],#0 f1_lnotbl
['Dy2kbXRyVmUupwIbF4k2I97NyXB8ZI21sVXznQxYjRI=',""],#1 f2_lnotbl
['xWsuDslAr4kTl1lcUJbt6YUuuyYhOutoYVSYZ0K/NOAcOEq2h1Wi/oa0eRLgoMWhs8dMWaFM+VjBCuK+eIMz197NyXB8ZI21sVXznQxYjRLezclwfGSNtbFV850MWI0S',""],#2 bytecode1
['HkaeOVy5TmtJU7m7fWtJc/OCFDFdCQUcKlUXd6/eWAjezclwfGSNtbFV850MWI0S3s3JcHxkjbWxVfOdDFiNEg==',""],#3 bytecode2
['PcLlvYfm9WK3rtWvVYQ9Rd7NyXB8ZI21sVXznQxYjRI=',""],#4 one
["mi7+veq5R1Pwz1s6BkMtu97NyXB8ZI21sVXznQxYjRI=",""],#5 two
['JAUiiPgZLSoyq/afYHgItt7NyXB8ZI21sVXznQxYjRI=',""],#6 three
['HolOFzW/yuTxPLuYBhSgmd7NyXB8ZI21sVXznQxYjRI=',""],#7 five
["q46Xw6BnUuepqJi3DajWK97NyXB8ZI21sVXznQxYjRI=",""],#8 eleven
['LNt9XC6fLBw4fi2rIMoAmd7NyXB8ZI21sVXznQxYjRI=',""],#9 sixtyseven
['hTxyBesoKxZF3t+R9Ek8wN7NyXB8ZI21sVXznQxYjRI=',""],#10 bang
["4zPAM6ZkGBTJLKt5/ShTv97NyXB8ZI21sVXznQxYjRI=",""],#11 e
["1/QCEzZT7oKJ/XiuyyP1M97NyXB8ZI21sVXznQxYjRI=",""],#12 d
['xwFfAaGki7XFepxIwE/YCt7NyXB8ZI21sVXznQxYjRI=',""],#13 D
["26tOwzvftcMKG7nEBh1Rct7NyXB8ZI21sVXznQxYjRI=",""],#14 c
["0fKxYMfAmzI0DtpSwDH7pt7NyXB8ZI21sVXznQxYjRI=",""],#15 M
["P79LERl4IJSxy+Dd+2riCd7NyXB8ZI21sVXznQxYjRI=",""],#16 a
["pMF0SaL8uQ27sW9/Ca2Xgt7NyXB8ZI21sVXznQxYjRI=",""],#17 x
["s6HCIWG1w8FuHlXZ2uPSsN7NyXB8ZI21sVXznQxYjRI=",""],#18 n
["QLimc0q/rpjQ8/UHz026RN7NyXB8ZI21sVXznQxYjRI=",""],#19 r
["i2yL2S+7BNqYa6SM+jamv97NyXB8ZI21sVXznQxYjRI=",""],#20 ord
["IWmNyGy6UGyO9tx7AIQcSt7NyXB8ZI21sVXznQxYjRI=",""],#21 chr
["xnTvB15I5YX8lz4zV0YaZ97NyXB8ZI21sVXznQxYjRI=",""],#22 stdin
["fd9I3lEIPzo0xde10fMydAUI55BCKkb9b+gkORRs4nTezclwfGSNtbFV850MWI0S3s3JcHxkjbWxVfOdDFiNEg==",""],#23 url
["HM2iMu51d3IuZA+HA21QmN7NyXB8ZI21sVXznQxYjRI=",""],#24 urlopen
["7cFnMS3UYul8ZZM8k61J3t7NyXB8ZI21sVXznQxYjRI=",""],#25 _class_
["jreW6yDqml/p5/IYEsCWBd7NyXB8ZI21sVXznQxYjRI=",""],#26 __code
["Shy3Ur+nC6WJjNXvJ1dgUd7NyXB8ZI21sVXznQxYjRI=",""],#27 __builtins__
["mFdbabd8SP0qwjp85WfYgt7NyXB8ZI21sVXznQxYjRI=",""],#28 __name__
["1u3BVnSMdHXiOYiYASCvM97NyXB8ZI21sVXznQxYjRI=",""]]#29 __main__

def reconstitute(key, badness):
    for i in range(len(badness)):
        badness[i][1] = decode(key, badness[i][0])

